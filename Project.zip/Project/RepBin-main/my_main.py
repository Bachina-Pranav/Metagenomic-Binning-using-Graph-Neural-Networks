# !/usr/bin/env python
# -*- coding: utf8 -*-

import sys
import argparse
import networkx as nx
import time
from loader import *
from utils import sparse_to_tuple
from models import Learning
from models import Graph_Diffusion_Convolution
from evaluation import *
from utils import sample_constraints
import warnings
warnings.filterwarnings('ignore')
import torch
# Set random seeds for reproducibility
seed_value = 1337
import torch
from torch_geometric.nn.models import Node2Vec
import torch.nn.functional as F

# PyTorch
torch.manual_seed(seed_value)
torch.cuda.manual_seed(seed_value)

torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

from collections import Counter


parser = argparse.ArgumentParser('Unsup learning model.')
parser.add_argument('--dataset', type=str, default='Sim-5G', help='Dataset string.')
parser.add_argument('--n_clusters', type=int, default=5, help='Number of clusters.')
parser.add_argument('--alpha', type=float, default=0.01, help='Teleport probability in graph diffusion convolution operators.')
parser.add_argument('--eps', type=float, default=0.0001, help='Threshold epsilon to sparsify in graph diffusion convolution operators.')

parser.add_argument('--lr', type=float, default=0.005, help='Number of learning rate.')
parser.add_argument('--epochs', type=int, default=10000, help='Number of epochs.')
parser.add_argument('--hid_dim', type=int, default=32, help='Dimension of hidden2.')
parser.add_argument('--batch_size', type=int, default=1, help='Number of batch size.')
parser.add_argument('--weight_decay', type=float, default=5e-4, help='Weight for L2 loss on embedding matrix.')
parser.add_argument('--patience', type=int, default=20, help='Patience for early stopping (# of epochs).')
parser.add_argument('--lamb', type=float, default=0.2, help='Weight to balance constraints.')
parser.add_argument('--device', type=int, default=0)

args = parser.parse_args()

print('----------args----------')
for k in list(vars(args).keys()):
	print('%s: %s' % (k, vars(args)[k]))
print('----------args----------\n')

def save_embedding(model):
    torch.save(model.embedding.weight.data.cpu(), 'embedding.pt')

assembly_graph, constraints, ground_truth, Gx = load_data(args.dataset)
# print("Graph stats")
# print(assembly_graph.shape)
triplets = sample_constraints(constraints, ground_truth)
device = f'cuda:{args.device}' if torch.cuda.is_available() else 'cpu'
device = torch.device(device)
adj = Graph_Diffusion_Convolution(assembly_graph, args.alpha, args.eps)
adj = sparse_to_tuple(adj)
print("graph stats")
print(adj)
feats = assembly_graph.todense()
# print(feats.shape)
edge_index, edge_weights, shape = adj
edge_index = torch.tensor(edge_index)
edge_index = edge_index.long()
print(edge_index.shape)
edge_index = edge_index.reshape(2, -1)
# print(edge_index)
print(triplets.shape)
nodes1, nodes2 = np.split(triplets, 2, axis=1)

# Node2Vec Learning

model = Node2Vec(edge_index, 128, 40, 20, 10, sparse=True).to(device)
loader = model.loader(batch_size=518, shuffle=True,
                          num_workers=4)
optimizer = torch.optim.SparseAdam(list(model.parameters()), lr=0.01)

model.train()
for epoch in range(1, 50):
    for i, (pos_rw, neg_rw) in enumerate(loader):
        optimizer.zero_grad()
        # print(pos_rw.shape)
        # print(neg_rw.shape)
        emb = model.embedding.weight.data.cpu()
        # print(emb.shape)
        emb_cons_1 = torch.tensor(emb[nodes1].view(triplets.shape[0],128))
        emb_cons_2 = torch.tensor(emb[nodes2].view(triplets.shape[0],128))
        loss_c = torch.exp(-F.pairwise_distance(emb_cons_1, emb_cons_2, p=2)).mean()
        loss_n = model.loss(pos_rw.to(device), neg_rw.to(device))
        loss = args.lamb*loss_n + (1-args.lamb)*loss_c
        loss.backward()
        optimizer.step()

        if (i + 1) % 1 == 0:
            print(f'Epoch: {epoch:02d}, Step: {i+1:03d}/{len(loader)}, '
                      f'Loss: {loss:.4f}')
        print(loss_n,loss_c)
        # if (i + 1) % 100 == 0:  # Save model every 100 steps.
            # save_embedding(model)
    # save_embedding(model)

print("\nEvaluation:")
constraints = triplets
# print(ground_truth)
true_labels = ground_truth
lbls_idx = [k for k,v in true_labels.items()]
cons = [val for line in constraints for val in line if val in lbls_idx]
cons = [k for k,v in Counter(cons).items() if v>3]
n_clusters = len(Counter([true_labels[c] for c in cons]))
embs = model.embedding.weight.data.cpu()[cons]
labels = list(set([true_labels[i] for i in cons]))
labels_map = {idx:i for i,idx in enumerate(labels)}
lbls = {i:true_labels[idx] for i,idx in enumerate(cons)}

from sklearn.cluster import KMeans
kmeans = KMeans(n_clusters=5)
y_pred = kmeans.fit_predict(embs)
pred_labels = {i:j for i,j in enumerate(y_pred)}
p, r, ari, f1 = validate_performance(lbls, pred_labels)
print(p,r,ari,f1)
# model = Learning(feats.shape[0], args.hid_dim, args.n_clusters, args)
# pred_labels = model.train(adj, feats, Gx, triplets, constraints, ground_truth)
# p,r,f1,ari,nmi = evaluate_performance(ground_truth, pred_labels)
# print ("### Precision = %0.4f, Recall = %0.4f, F1 = %0.4f, ARI = %0.4f, NMI = %0.4f"  % (p,r,f1,ari,nmi))

